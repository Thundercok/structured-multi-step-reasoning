"""
Tesseract 5.5.2 Native CLI OCR Engine with TSV Bounding Box Support
"""

import logging
import math
import os
import subprocess
import time
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


class TesseractOCREngine:
    def __init__(self, tesseract_cmd: str = "/opt/homebrew/bin/tesseract", *, timeout: float = 15, languages: str = "vie+eng"):
        if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or not math.isfinite(timeout) or timeout <= 0:
            raise ValueError("timeout must be positive and finite")
        self.timeout = timeout
        self.languages = languages
        self.tesseract_cmd = tesseract_cmd if os.path.exists(tesseract_cmd) else "tesseract"

    def run_ocr(self, image_path: str) -> Dict[str, Any]:
        """
        Runs Tesseract OCR on an image.
        Returns full text, individual lines, and tokens with bounding boxes.
        """
        if not os.path.isfile(image_path):
            logger.warning("Image file not found: %s", image_path)
            return {"full_text": "", "lines": [], "tokens": []}

        tokens = []
        full_text = ""
        deadline = time.monotonic() + self.timeout

        # 1. Try TSV mode for bounding boxes
        try:
            cmd_tsv = [self.tesseract_cmd, image_path, "stdout", "-l", self.languages, "--oem", "1", "tsv"]
            res_tsv = subprocess.run(cmd_tsv, capture_output=True, text=True, timeout=self.timeout,
                                     encoding="utf-8", errors="replace")
            if res_tsv.returncode == 0 and res_tsv.stdout.strip():
                tokens = self._parse_tsv_output(res_tsv.stdout)
                lines_by_id = {}
                for token in tokens:
                    key = (token["page_num"], token["block_num"], token["par_num"], token["line_num"])
                    lines_by_id.setdefault(key, []).append(token["text"])
                full_text = "\n".join(" ".join(words) for words in lines_by_id.values())
                logger.info("Tesseract TSV mode: extracted %d tokens from %s", len(tokens), os.path.basename(image_path))
        except (subprocess.TimeoutExpired, FileNotFoundError):
            return {"full_text": "", "lines": [], "tokens": []}
        except Exception as e:
            logger.warning("Tesseract TSV mode failed for %s: %s", image_path, e)

        # 2. Fallback to plain text mode if TSV didn't work
        if not full_text:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return {"full_text": "", "lines": [], "tokens": []}
            try:
                cmd_text = [self.tesseract_cmd, image_path, "stdout", "-l", self.languages, "--oem", "1"]
                res_text = subprocess.run(cmd_text, capture_output=True, text=True, timeout=remaining,
                                          encoding="utf-8", errors="replace")
                full_text = res_text.stdout if res_text.returncode == 0 else ""
                logger.info("Tesseract text mode: extracted %d chars from %s", len(full_text), os.path.basename(image_path))
            except Exception as e:
                logger.warning("Tesseract text mode also failed for %s: %s", image_path, e)
                return {"full_text": "", "lines": [], "tokens": []}

        lines = [line.strip() for line in full_text.splitlines() if line.strip()]

        return {
            "full_text": full_text,
            "lines": lines,
            "tokens": tokens
        }

    def _parse_tsv_output(self, tsv_text: str) -> List[Dict[str, Any]]:
        """
        Parse Tesseract TSV output into token dicts with bounding boxes.
        TSV columns: level, page_num, block_num, par_num, line_num, word_num,
                     left, top, width, height, conf, text
        """
        tokens = []
        lines = tsv_text.strip().split("\n")
        if len(lines) < 2:  # Need at least header + 1 data line
            return tokens

        # Skip header line
        for line in lines[1:]:
            parts = line.split("\t", 11)
            if len(parts) < 12:
                continue

            try:
                conf = float(parts[10])
                text = parts[11].strip()

                # Skip empty text or low-confidence noise (conf < 0 means no text)
                if not text or not math.isfinite(conf) or not 0 <= conf <= 100 or int(parts[0]) != 5:
                    continue

                left = int(parts[6])
                top = int(parts[7])
                width = int(parts[8])
                height = int(parts[9])
                if left < 0 or top < 0 or width <= 0 or height <= 0:
                    continue

                tokens.append({
                    "text": text,
                    "confidence": conf / 100.0,  # Normalize to 0.0-1.0
                    "bbox": [left, top, left + width, top + height],
                    "level": int(parts[0]),
                    "page_num": int(parts[1]),
                    "block_num": int(parts[2]),
                    "par_num": int(parts[3]),
                    "line_num": int(parts[4]),
                    "word_num": int(parts[5]),
                })
            except (ValueError, IndexError):
                continue

        return tokens
