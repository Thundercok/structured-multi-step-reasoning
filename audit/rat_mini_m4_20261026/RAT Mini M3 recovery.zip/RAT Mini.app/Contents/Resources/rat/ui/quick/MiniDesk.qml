import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Dialogs

// Mini projection of RAT's paper/composer layout. Buttons, icons and file cards
// are the production components also used by PDFDesk, not widget imitations.
Rectangle {
    id: desk
    objectName: "miniDesk"
    color: "transparent"
    property var liveController
    property var liveSnapshot: ({mode:"find",finderHits:[],busy:false})
    property url mascotSource
    property bool darkMode: false
    property bool reduceMotion: false
    property real maxPaperHeight: 420
    property int selectedFinderIndex: -1
    property bool showAllFinderHits: false
    property string lastSubmittedText: ""
    readonly property var allFinderHits: liveSnapshot.finderHits || []
    readonly property var visibleFinderHits: showAllFinderHits ? allFinderHits : allFinderHits.slice(0, 3)
    readonly property int remainingFinderHits: Math.max(0, allFinderHits.length - 3)
    readonly property bool paperVisible: liveSnapshot.expanded && liveSnapshot.hasWorkbench
    readonly property real preferredWindowHeight: Math.max(settingsDialog.visible ? 600 : 0, composer.height + Math.max(148, paperVisible ? resultPaper.height + 24 : 148) + 32)
    readonly property color ink: darkMode ? "#eef0e9" : "#2c302a"
    readonly property color muted: darkMode ? "#b7bdaf" : "#62695e"
    readonly property color paperColor: darkMode ? "#272d25" : "#fdfdf9"
    readonly property color inputColor: darkMode ? "#2b3227" : "#fdfefb"
    readonly property color backingColor: darkMode ? "#3a4332" : "#e8ece1"
    readonly property color edge: darkMode ? "#424d39" : "#e0e5d8"
    readonly property color accent: darkMode ? "#c0d2a7" : "#4f6740"
    readonly property color accentText: darkMode ? "#24301b" : "#fafcf5"
    readonly property color selectedSurface: darkMode ? "#2d3727" : "#edf4e8"
    readonly property color selectedEdge: darkMode ? "#46593d" : "#b5ceaa"
    readonly property color utilitySurface: darkMode ? "#242820" : "#f0f4ea"
    readonly property color hoverSurface: darkMode ? "#2a3125" : "#f1f6ed"
    readonly property color pdfInk: darkMode ? "#dbaa9f" : "#a15e50"
    readonly property int cardRadius: 10
    readonly property int controlRadius: 10
    signal moveRequested()
    signal hideRequested()
    Component.onCompleted: { liveSnapshot = liveController.snapshot; editor.forceActiveFocus() }

    function submitDraft() {
        lastSubmittedText = editor.text
        selectedFinderIndex = -1
        liveController.submit(editor.text)
    }
    function openSettings() {
        var p = liveController.preferences
        folderList.model = p.roots.slice()
        sourceLanguage.currentIndex = Math.max(0, sourceLanguage.indexOfValue(p.source_language))
        targetLanguage.currentIndex = Math.max(0, targetLanguage.indexOfValue(p.target_language))
        backend.currentIndex = Math.max(0, backend.indexOfValue(p.translation_provider))
        freeFallback.checked = p.free_fallback
        settingsError.text = ""
        settingsDialog.open()
    }
    Connections {
        target: liveController
        function onChanged() {
            var next = liveController.snapshot
            if (next.view === "finder" && next.phase !== "working" && desk.liveSnapshot.phase === "working") {
                desk.showAllFinderHits = false
                desk.selectedFinderIndex = next.finderHits.length > 0 ? 0 : -1
            }
            desk.liveSnapshot = next
        }
        function onSettingsRequested() { desk.openSettings() }
    }
    onSelectedFinderIndexChanged: Qt.callLater(function() {
        if (selectedFinderIndex >= 0) finderResults.scrollSelectionIntoView(selectedFinderIndex)
    })

    Rectangle {
        visible: desk.paperVisible
        x: resultPaper.x - 6; y: resultPaper.y - 5
        width: resultPaper.width; height: resultPaper.height
        radius: 16; color: desk.backingColor
        rotation: -0.6
    }
    Rectangle {
        id: resultPaper
        objectName: "resultPaper"
        visible: desk.paperVisible
        x: composer.x + (desk.width < 580 ? 38 : 112)
        y: composer.y + 16 - height
        width: composer.x + composer.width - x
        height: Math.min(desk.maxPaperHeight, resultColumn.implicitHeight + 72)
        radius: 16
        color: desk.paperColor
        border.color: desk.edge
        clip: true
        Behavior on height { enabled: !desk.reduceMotion; NumberAnimation { duration: 140; easing.type: Easing.OutCubic } }
        ScrollView {
            anchors.fill: parent
            anchors.margins: 16
            anchors.bottomMargin: 44
            contentWidth: availableWidth
            clip: true
            ScrollBar.horizontal.policy: ScrollBar.AlwaysOff
            ColumnLayout {
                id: resultColumn
                width: parent.width
                spacing: 10
                RowLayout {
                    Layout.fillWidth: true
                    Label {
                        objectName: "resultStatus"
                        Layout.fillWidth: true
                        text: desk.liveSnapshot.status
                        textFormat: Text.PlainText
                        color: desk.liveSnapshot.error ? desk.pdfInk : desk.ink
                        font.pixelSize: 13
                        font.weight: Font.Medium
                        wrapMode: Text.Wrap
                        Accessible.name: text
                    }
                    QuietButton {
                        text: ""; iconName: "chevron-down"; implicitWidth: 26
                        Accessible.name: "Thu gọn kết quả"
                        onClicked: desk.liveController.setExpanded(false)
                    }
                }
                BusyIndicator {
                    Layout.alignment: Qt.AlignHCenter
                    running: desk.liveSnapshot.busy
                    visible: running
                    implicitWidth: 24; implicitHeight: 24
                    Accessible.name: "Đang thực hiện yêu cầu"
                }
                FinderResultsView {
                    id: finderResults
                    fileActionsOnly: true
                    enabled: !desk.liveSnapshot.busy
                }
                TextArea {
                    objectName: "translationText"
                    visible: desk.liveSnapshot.view === "translation" && Boolean(text)
                    Layout.fillWidth: true
                    text: desk.liveSnapshot.text
                    textFormat: TextEdit.PlainText
                    readOnly: true
                    selectByMouse: true
                    wrapMode: TextEdit.Wrap
                    color: desk.ink
                    font.pixelSize: 15
                    padding: 0
                    background: null
                    Accessible.name: "Bản dịch"
                }
                Label {
                    visible: Boolean(text) && !desk.liveSnapshot.busy
                    Layout.fillWidth: true
                    text: desk.liveSnapshot.meta
                    textFormat: Text.PlainText
                    color: desk.muted
                    font.pixelSize: 11
                    wrapMode: Text.Wrap
                }
                QuietButton {
                    visible: desk.liveSnapshot.view === "translation" && Boolean(desk.liveSnapshot.text)
                    text: "Sao chép bản dịch"; iconName: "copy"
                    onClicked: { desk.liveController.copyResult(); text = "Đã sao chép"; copiedTimer.restart() }
                    Timer { id: copiedTimer; interval: 1800; onTriggered: parent.text = "Sao chép bản dịch" }
                }
            }
        }
    }

    Item {
        objectName: "mascotCrop"
        visible: !desk.paperVisible
        x: Math.max(16, composer.x - 58)
        y: composer.y - 116
        width: 122; height: 116
        clip: true
        Image {
            width: 180
            height: width * sourceSize.height / Math.max(1, sourceSize.width)
            source: desk.mascotSource
            fillMode: Image.PreserveAspectFit
            smooth: true
            Accessible.ignored: true
        }
        MouseArea { anchors.fill: parent; onPressed: desk.moveRequested() }
    }
    Rectangle {
        visible: !desk.paperVisible
        x: composer.x + 112; y: composer.y - height + 7
        width: Math.min(300, composer.width - 112)
        height: hint.implicitHeight + 24
        radius: 12
        color: desk.paperColor; border.color: desk.edge
        Label {
            id: hint
            anchors.fill: parent; anchors.margins: 12
            text: desk.liveSnapshot.hasWorkbench ? desk.liveSnapshot.status : "Bạn muốn tìm gì, hay dịch đoạn nào?"
            color: desk.ink; font.pixelSize: 13
            wrapMode: Text.Wrap; maximumLineCount: 2; elide: Text.ElideRight
            textFormat: Text.PlainText
        }
        MouseArea {
            anchors.fill: parent
            enabled: desk.liveSnapshot.hasWorkbench
            onClicked: desk.liveController.setExpanded(true)
        }
    }
    Rectangle {
        id: composer
        objectName: "composer"
        x: Math.max(24, (desk.width - width) / 2)
        y: desk.height - height - 16
        width: Math.min(580, desk.width - 64)
        height: editorColumn.implicitHeight + 24
        radius: 18
        color: desk.inputColor
        border.width: 1
        border.color: editor.activeFocus ? desk.selectedEdge : desk.edge
        ColumnLayout {
            id: editorColumn
            x: 14; y: 12; width: parent.width - 28
            spacing: 5
            RowLayout {
                Layout.fillWidth: true
                spacing: 3
                QuietButton {
                    objectName: "findMode"
                    text: "Tìm file"; iconName: "search"
                    highlighted: desk.liveSnapshot.mode === "find"
                    onClicked: { desk.selectedFinderIndex = -1; desk.liveController.setMode("find"); editor.forceActiveFocus() }
                }
                QuietButton {
                    objectName: "translateMode"
                    text: "Dịch"; iconName: "sparkle"
                    highlighted: desk.liveSnapshot.mode === "translate"
                    onClicked: { desk.selectedFinderIndex = -1; desk.liveController.setMode("translate"); editor.forceActiveFocus() }
                }
                Item { Layout.fillWidth: true; implicitHeight: 26; MouseArea { anchors.fill: parent; onPressed: desk.moveRequested() } }
                QuietButton {
                    text: ""; iconName: "minus"; implicitWidth: 26
                    Accessible.name: "Ẩn RAT Mini"
                    onClicked: desk.hideRequested()
                }
                QuietButton {
                    text: "⋯"; implicitWidth: 26
                    Accessible.name: "Cài đặt RAT Mini"
                    onClicked: desk.openSettings()
                }
            }
            RowLayout {
                Layout.fillWidth: true
                ScrollView {
                    Layout.fillWidth: true
                    Layout.preferredHeight: Math.min(100, Math.max(36, editor.implicitHeight))
                    contentWidth: availableWidth
                    ScrollBar.horizontal.policy: ScrollBar.AlwaysOff
                    clip: true
                    TextArea {
                        id: editor
                        objectName: "miniEditor"
                        placeholderText: desk.liveSnapshot.mode === "find" ? "Tên hoặc mô tả file…" : "Nhập đoạn cần dịch…"
                        color: desk.ink; placeholderTextColor: desk.muted
                        font.pixelSize: 15
                        textFormat: TextEdit.PlainText
                        selectByMouse: true; wrapMode: TextEdit.Wrap
                        padding: 3; background: null
                        Accessible.name: "Yêu cầu RAT Mini"
                        onTextChanged: desk.selectedFinderIndex = -1
                        Keys.onDownPressed: event => {
                            if (desk.liveSnapshot.view === "finder" && desk.paperVisible && desk.visibleFinderHits.length) {
                                desk.selectedFinderIndex = (desk.selectedFinderIndex + 1) % desk.visibleFinderHits.length
                                event.accepted = true
                            } else event.accepted = false
                        }
                        Keys.onUpPressed: event => {
                            if (desk.liveSnapshot.view === "finder" && desk.paperVisible && desk.visibleFinderHits.length) {
                                desk.selectedFinderIndex = (desk.selectedFinderIndex - 1 + desk.visibleFinderHits.length) % desk.visibleFinderHits.length
                                event.accepted = true
                            } else event.accepted = false
                        }
                        function handleReturn(event) {
                            if (event.modifiers & Qt.ShiftModifier) { event.accepted = false; return }
                            event.accepted = true
                            if (desk.liveSnapshot.busy) return
                            if (desk.liveSnapshot.view === "finder" && desk.paperVisible && desk.selectedFinderIndex >= 0 && editor.text === desk.lastSubmittedText) {
                                if (event.modifiers & Qt.ControlModifier || event.modifiers & Qt.MetaModifier)
                                    desk.liveController.revealSelectedInFinder(desk.selectedFinderIndex)
                                else desk.liveController.openSelectedHit(desk.selectedFinderIndex)
                            } else desk.submitDraft()
                        }
                        Keys.onReturnPressed: event => handleReturn(event)
                        Keys.onEnterPressed: event => handleReturn(event)
                    }
                }
                QuietButton {
                    objectName: "sendButton"
                    text: ""; primary: true
                    iconName: desk.liveSnapshot.busy ? "stop" : "arrow-up"
                    implicitWidth: 32; implicitHeight: 32
                    Accessible.name: desk.liveSnapshot.busy ? "Dừng yêu cầu" : "Gửi yêu cầu"
                    onClicked: { if (desk.liveSnapshot.busy) desk.liveController.cancel(); else desk.submitDraft() }
                }
            }
            RowLayout {
                Layout.fillWidth: true
                Label { text: "RAT Mini · M3"; color: desk.muted; font.pixelSize: 10; opacity: 0.65 }
                Item { Layout.fillWidth: true }
                QuietButton {
                    objectName: "clipboardButton"
                    text: "Dịch Clipboard"; iconName: "copy"
                    font.pixelSize: 11; topPadding: 3; bottomPadding: 3
                    onClicked: desk.liveController.translateClipboard()
                }
                QuietButton {
                    visible: desk.liveSnapshot.hasWorkbench
                    text: desk.paperVisible ? "Thu gọn" : "Kết quả"
                    font.pixelSize: 11; topPadding: 3; bottomPadding: 3
                    onClicked: desk.liveController.setExpanded(!desk.paperVisible)
                }
            }
        }
    }
    Shortcut { sequence: "Escape"; onActivated: { if (settingsDialog.visible) settingsDialog.close(); else desk.hideRequested() } }
    Shortcut { sequence: "Ctrl+Q"; onActivated: desk.liveController.quit() }
    Shortcut { sequence: "Meta+Q"; onActivated: desk.liveController.quit() }
    Shortcut { sequence: "Meta+,"; onActivated: desk.openSettings() }

    FolderDialog {
        id: folderDialog
        title: "Chọn thư mục để tìm file"
        onAccepted: {
            var path = decodeURIComponent(String(selectedFolder).replace(/^file:\/\//, ""))
            var roots = folderList.model.slice()
            if (roots.indexOf(path) < 0) roots.push(path)
            folderList.model = roots
        }
    }
    Dialog {
        id: settingsDialog
        objectName: "miniSettings"
        title: "Cài đặt RAT Mini"
        modal: true; focus: true
        width: Math.min(560, desk.width - 24)
        height: Math.min(510, desk.height - 20)
        x: (desk.width - width) / 2; y: (desk.height - height) / 2
        padding: 16
        background: Rectangle { color: desk.paperColor; radius: 16; border.color: desk.edge }
        contentItem: ScrollView {
            clip: true; contentWidth: availableWidth
            ColumnLayout {
                width: parent.width; spacing: 10
                Label { text: "Thư mục tìm file"; color: desk.ink; font.weight: Font.Medium }
                Repeater {
                    id: folderList
                    model: []
                    RowLayout {
                        required property string modelData
                        required property int index
                        Layout.fillWidth: true
                        Label { text: modelData; textFormat: Text.PlainText; color: desk.muted; elide: Text.ElideMiddle; Layout.fillWidth: true }
                        QuietButton { text: "Bỏ"; onClicked: { var roots=folderList.model.slice(); roots.splice(index,1); folderList.model=roots } }
                    }
                }
                QuietButton { text: "Thêm thư mục…"; iconName: "folder"; onClicked: folderDialog.open() }
                Label { text: "Ngôn ngữ nguồn"; color: desk.ink }
                ComboBox {
                    id: sourceLanguage; Layout.fillWidth: true
                    textRole: "label"; valueRole: "value"
                    model: [{label:"Tự nhận diện",value:"auto"},{label:"English",value:"en"},{label:"Tiếng Việt",value:"vi"},{label:"日本語",value:"ja"},{label:"한국어",value:"ko"},{label:"中文",value:"zh"},{label:"Français",value:"fr"},{label:"Deutsch",value:"de"}]
                }
                Label { text: "Dịch sang"; color: desk.ink }
                ComboBox {
                    id: targetLanguage; Layout.fillWidth: true
                    textRole: "label"; valueRole: "value"
                    model: [{label:"Tiếng Việt",value:"vi"},{label:"English",value:"en"},{label:"日本語",value:"ja"},{label:"한국어",value:"ko"},{label:"中文",value:"zh"},{label:"Français",value:"fr"},{label:"Deutsch",value:"de"}]
                }
                Label { text: "Dịch vụ dịch"; color: desk.ink }
                ComboBox {
                    id: backend; Layout.fillWidth: true
                    textRole: "label"; valueRole: "value"
                    model: [{label:"Google Translate online",value:"google_gtx"},{label:"MyMemory",value:"mymemory"},{label:"LLM đã cấu hình",value:"llm"},{label:"DeepL đã cấu hình",value:"deepl"},{label:"Google Cloud đã cấu hình",value:"google"}]
                }
                CheckBox { id: freeFallback; text: "Cho phép MyMemory dự phòng" }
                Label {
                    Layout.fillWidth: true; wrapMode: Text.Wrap
                    text: "Dịch cần Internet; đoạn cần dịch được gửi đến dịch vụ đã chọn. Tìm file dùng Spotlight trên máy."
                    color: desk.muted; font.pixelSize: 11
                }
                Label { id: settingsError; Layout.fillWidth: true; wrapMode: Text.Wrap; color: desk.pdfInk; visible: Boolean(text) }
                RowLayout {
                    Item { Layout.fillWidth: true }
                    QuietButton { text: "Đóng"; onClicked: settingsDialog.close() }
                    QuietButton {
                        text: "Lưu cài đặt"; primary: true
                        onClicked: {
                            settingsError.text = desk.liveController.savePreferences({roots:folderList.model,source_language:sourceLanguage.currentValue,target_language:targetLanguage.currentValue,translation_provider:backend.currentValue,free_fallback:freeFallback.checked})
                            if (!settingsError.text) settingsDialog.close()
                        }
                    }
                }
            }
        }
    }
}
